<?php
return array (
    'black_keyword_list' =>
        array (

        ),
    'black_ip_list' =>
        array (

        ),
);